package com.qa.test;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.Base;
import com.qa.methods.HttpMethods;

public class DeleteMethodTest extends Base {

	Base base;
	String Rdomain;
	String Ruri;
	String url;
	HttpMethods hm;

	@BeforeMethod
	public void setUp() throws ClientProtocolException, IOException {
		base = new Base();
		Rdomain = prop.getProperty("domain");
		Ruri = prop.getProperty("URI");

		url = Rdomain + Ruri;

	}

	@Test
	public void deleteMethod() throws ClientProtocolException, IOException {

		hm = new HttpMethods();
		hm.delete(url);
	}

}
