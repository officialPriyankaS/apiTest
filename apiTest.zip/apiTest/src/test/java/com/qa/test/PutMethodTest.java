package com.qa.test;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.qa.base.Base;
import com.qa.data.Data;
import com.qa.data.PutData;
import com.qa.methods.HttpMethods;

public class PutMethodTest extends Base {
	Base testBase;
	String Rdomain;
	String Ruri;
	String url;
	HttpMethods hm;
	HttpResponse response;

	@BeforeMethod
	public void setUp() throws ClientProtocolException, IOException {
		testBase = new Base();
		Rdomain = prop.getProperty("domain");
		Ruri = prop.getProperty("URI");
		// https://reqres.in/api/users

		url = Rdomain + Ruri;

	}

	@Test
	public void putAPITest() throws IOException {
		hm = new HttpMethods();

		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");

		ObjectMapper mapper = new ObjectMapper();
		PutData data = new PutData("morpheus", "zion");

		mapper.writeValue(new File(System.getProperty("user.dir") + "/src/main/java/com/qa/data/data.json"), data);

		String dataJsonString = mapper.writeValueAsString(data);
		System.out.println(dataJsonString);

		response = hm.put(url, dataJsonString, headerMap);

		int statusCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code" + statusCode);

		String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");

		JSONObject responseJson = new JSONObject(responseString);
		System.out.println("The response from API is:" + responseJson);

	}
}
