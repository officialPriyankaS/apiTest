package com.qa.methods;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpOptions;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

public class HttpMethods {

	// --------------------------GET method------------------------>
	public void get(String url) throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
		// CloseableHttpClient client=HttpClients.createDefault();
		HttpGet request = new HttpGet(url);
		// CloseableHttpResponse response = client.execute(request);

		HttpResponse response = client.execute(request);

		// Response Status Code
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code : " + responseCode);

		// Response Payload
		BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
		StringBuffer responsePayload = new StringBuffer();
		String line = "";
		while ((line = in.readLine()) != null) {
			responsePayload.append(line);
		}
		System.out.println("Response Payload : " + responsePayload);
	}

	// --------------------------POST method------------------------>

	public HttpResponse post(String url, String entityString, HashMap<String, String> headerMap)
			throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
		// CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPost httppost = new HttpPost(url);
		httppost.setEntity(new StringEntity(entityString));

		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httppost.addHeader(entry.getKey(), entry.getValue());
		}

		HttpResponse response = client.execute(httppost);
		return response;

	}

	// --------------------------PUT method------------------------>
	public HttpResponse put(String url, String entityString, HashMap<String, String> headerMap)
			throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
		// CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPut httpput = new HttpPut(url);
		httpput.setEntity(new StringEntity(entityString));

		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httpput.addHeader(entry.getKey(), entry.getValue());
		}

		HttpResponse response = client.execute(httpput);
		return response;

	}

	// --------------------------Delete method------------------------>
	public void delete(String url) throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
		// CloseableHttpClient client=HttpClients.createDefault();
		HttpDelete request = new HttpDelete(url);

		// CloseableHttpResponse response = client.execute(request);

		HttpResponse response = client.execute(request);

		// Response Status Code
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code : " + responseCode);
	}

	// --------------------------PATCH method------------------------>
	public HttpResponse patch(String url, String entityString, HashMap<String, String> headerMap)
			throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
		// CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPatch httppatch = new HttpPatch(url);
		httppatch.setEntity(new StringEntity(entityString));

		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httppatch.addHeader(entry.getKey(), entry.getValue());
		}

		HttpResponse response = client.execute(httppatch);
		return response;

	}

	// --------------------------HEAD method------------------------>
	public void head(String url) throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
		HttpHead request = new HttpHead(url);
		HttpResponse response = client.execute(request);

		// Response Status Code
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code : " + responseCode);

		// Response
		Header[] rs = response.getAllHeaders();
		for (Header resp : rs) {
			System.out.println("Response Header : " + resp);
		}

	}

	// --------------------------OPTIONS method------------------------>
	public void options(String url) throws ClientProtocolException, IOException {
		HttpClient client = HttpClientBuilder.create().build();
		HttpOptions request = new HttpOptions(url);
		HttpResponse response = client.execute(request);

		// Response Status Code
		int responseCode = response.getStatusLine().getStatusCode();
		System.out.println("Response Code : " + responseCode);

		Header[] rs = response.getAllHeaders();
		for (Header resp : rs) {

			System.out.println("Response Header : " + resp);
		}

	}
}
