package com.qa.data;

public class PutData {
	String name;
	String job;
	String updateddAt;
	

	public PutData() {

	}

	public PutData(String name, String job) {
		this.name = name;
		this.job = job;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}
	
	public String getUpdateddAt() {
		return updateddAt;
	}

	public void setUpdateddAt(String updateddAt) {
		this.updateddAt = updateddAt;
	}

}
